<?php

$conn = mysqli_connect("localhost","root","","db_data");

if(!$conn){
    echo "connection failed";
}


?>